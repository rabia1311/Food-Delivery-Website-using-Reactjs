import React from "react";
import cartItems from "../pages/Menu";
import Layout from "../components/Layout";

const Cartcontext = () => {
  return (
    <>
      <Layout>
        <div>
          <h1>Cart</h1>
          <ul>
            {cartItems &&
              cartItems.map((item, index) => (
                <li key={index}>
                  {item.name} - Rs{item.price}
                </li>
              ))}
          </ul>
        </div>
      </Layout>
    </>
  );
};
export default Cartcontext;
