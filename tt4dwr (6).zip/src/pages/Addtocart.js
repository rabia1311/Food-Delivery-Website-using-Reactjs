import React from "react";

import Layout from "../components/Layout";
const Addtocart = () => {
  return (
    <Layout>
      <div>
        <h1> ADD TO CART AREA</h1>
      </div>
    </Layout>
  );
};
export default Addtocart;
