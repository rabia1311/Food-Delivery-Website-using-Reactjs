import React, { useState } from "react";
//import Viewcart from "../pages/Viewcart";
import ShoppingCartTwoToneIcon from "@mui/icons-material/ShoppingCartTwoTone";
import {
  AppBar,
  Box,
  Typography,
  Toolbar,
  IconButton,
  Drawer,
  Divider,
  List,
  ListItem,
  ListItemText
} from "@mui/material";
import FastfoodOutlinedIcon from "@mui/icons-material/FastfoodOutlined";
import { Link } from "react-router-dom";
import MenuIcon from "@mui/icons-material/Menu";

const Header = () => {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [cartItems, setCartItems] = useState([]);
  const [cartVisible, setCartVisible] = useState(false);
  //handle menu click
  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };
  const handleDrawerCart = () => {
    setIsCartOpen(!isCartOpen);
  };

  const handleAddToCart = (item) => {
    setCartItems([...cartItems, item]);
  };
  const removeItemFromCart = (index) => {
    const newCartItems = [...cartItems];
    newCartItems.splice(index, 1);
    setCartItems(newCartItems);
  };
  function toggleCart() {
    setCartVisible(!cartVisible);
  }

  //menu drawer
  const drawer = (
    <Box onClick={handleDrawerToggle} sx={{ textAlign: "center" }}>
      <Typography
        color={"goldenrod"}
        variant="h5"
        component="div"
        sx={{ flexGrow: 1 }}
      >
        <FastfoodOutlinedIcon />
        FOODIE
      </Typography>
      <Divider />

      <ul className="mobile-navigation">
        <li>
          <div>View Cart </div>
          <Link to={"/Cartpage"}>View Cart </Link>
        </li>
        <li>
          <Link to={"/"}>Home</Link>
        </li>
        <li>
          <Link to={"/menu"}>Menu</Link>
        </li>
        <li>
          <Link to={"/about"}>About</Link>
        </li>
        <li>
          <Link to={"/contact"}>Contact</Link>
        </li>
      </ul>
    </Box>
  );

  const displayCartItems = () => {
    return cartItems.map((item, index) => (
      <div key={index}>
        <span>{item.name}</span>
        <span>{item.price}</span>
        <button onClick={() => removeItemFromCart(index)}>Remove</button>
      </div>
    ));
  };
  return (
    <>
      <header>
        <div className="cart-icon">
          <img src="./images/cart.jpg" alt="cart" />
        </div>
      </header>
      <Box>
        <AppBar component={"nav"} sx={{ bgcolor: "black" }}>
          <Toolbar>
            <IconButton
              color="inherit"
              aria-label="open drawer"
              edge="start"
              sx={{ mr: 2, display: { xs: "none", sm: "block" } }}
              onClick={handleDrawerToggle}
            >
              <MenuIcon />
            </IconButton>
            <Typography
              color={"goldenrod"}
              variant="h5"
              component="div"
              sx={{ flexGrow: 1 }}
            >
              <FastfoodOutlinedIcon />
              FOODIE
            </Typography>
            <Box sx={{ display: { xs: "none", sm: "block" } }}>
              <ul className="navigation-menu">
                <div>
                  <IconButton color="black">
                    <ShoppingCartTwoToneIcon />
                  </IconButton>

                  <Drawer
                    variant="temporary"
                    anchor="right"
                    open={isCartOpen}
                    onClose={handleDrawerCart}
                    sx={{
                      display: { xs: "none", sm: "block" },
                      width: "240px",
                      "& .MuiDrawer-paper": {
                        boxSizing: "border-box",
                        width: "240px"
                      }
                    }}
                  >
                    <ul>
                      {cartItems.map((item) => (
                        <li key={item.name}>
                          {item.name} - ${item.price}
                        </li>
                      ))}
                    </ul>
                    <ul>
                      <li
                        onClick={() =>
                          handleAddToCart({ name: "pizza", price: 10 })
                        }
                      >
                        Item 1
                      </li>

                      <li
                        onClick={() =>
                          handleAddToCart({ name: "coldrink", price: 20 })
                        }
                      >
                        Item 2
                      </li>

                      <li
                        onClick={() =>
                          handleAddToCart({ name: "cake", price: 40 })
                        }
                      >
                        Item 3
                      </li>
                      <div>{displayCartItems()}</div>
                    </ul>
                  </Drawer>
                </div>
                <li>
                  <Link to={"/Cartpage"}>View Cart</Link>
                </li>

                <li>
                  <Link to={"/"}>Home</Link>
                </li>
                <li>
                  <Link to={"/menu"}>Menu</Link>
                </li>
                <li>
                  <Link to={"/about"}>About</Link>
                </li>
                <li>
                  <Link to={"/contact"}>Contact</Link>
                </li>
              </ul>
            </Box>
          </Toolbar>
        </AppBar>
        <Box component="nav">
          <Drawer
            variant="temporary"
            open={mobileOpen}
            onClose={handleDrawerToggle}
            sx={{
              display: { xs: "none", sm: "block" },
              width: "240px",
              "& .MuiDrawer-paper": {
                boxSizing: "border-box",
                width: "240px"
              }
            }}
          >
            {drawer}
          </Drawer>
        </Box>
        <Box>
          <Toolbar />
        </Box>
      </Box>
    </>
  );
};

export default Header;
