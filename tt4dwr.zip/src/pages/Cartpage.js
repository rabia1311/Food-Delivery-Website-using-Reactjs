import React, { useState, useContext, useEffect } from "react";
import Layout from "../components/Layout";
import itemlist from "../pages/data";
import "../Style/cart.css";
//import FormatPrice from "../pages/FormatPrice";
import { Route, Link, Routes, useNavigate } from "react-router-dom";
import Cartamounttoggle from "../pages/Cartamounttoggle";
import updatedCartItems from "../pages/Menu";
import { FaTrash } from "react-icons/fa";

const CartPage = ({ cartItems }) => {
  const navigate = useNavigate();
  const goBack = () => {
    navigate(-1);
  };
  const data = JSON.parse(localStorage.getItem("cartItems"));
  console.log("dataa", data);
  const [counts, setCounts] = useState(data.map(() => 1));

  const handleIncrement = (index) => {
    setCounts((prevCounts) => {
      const newCounts = [...prevCounts];
      newCounts[index] = newCounts[index] + 1;
      return newCounts;
    });
  };
  const handleDecrement = (index) => {
    setCounts((prevCounts) => {
      const newCounts = [...prevCounts];
      if (newCounts[index] > 1) {
        newCounts[index] = newCounts[index] - 1;
      }
      return newCounts;
    });
  };
  const handleRemove = (index) => {
    const newData = [...data];
    newData.splice(index, 1);
    localStorage.setItem("cartItems", JSON.stringify(newData));
    setCounts((prevCounts) => {
      const newCounts = [...prevCounts];
      newCounts.splice(index, 1);
      return newCounts;
    });
  };

  const shippingFee = 5;

  return (
    <Layout>
      <div>
        <h1>In your Cart - </h1>
        <table>
          <thead>
            <tr>
              <th>Item</th>
              <th>Price</th>
              <th>Remove</th>
              <th>Quantity</th>
              <th>Subtotal</th>
            </tr>
          </thead>
          <tbody>
            {data.map((item, index) => (
              <tr key={index}>
                <td>{item.name}</td>
                <td> Rs{item.price}</td>

                <td>
                  <FaTrash
                    className="remove_icon"
                    onClick={() => handleRemove(index)}
                  />
                </td>
                <td>
                  <button onClick={() => handleIncrement(index)}>+</button>
                  <span>{counts[index]}</span>
                  <button onClick={() => handleDecrement(index)}> - </button>
                </td>

                <td>Rs {item.price * counts[index]}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <br />
        Shiiping fee = {shippingFee}
        <br />
        YOUR TOTAL = Rs{" "}
        {data.reduce((total, item, index) => {
          return total + item.price * counts[index];
        }, 0) + shippingFee}
        <hr />
        <button onClick={goBack}> Go back</button> <button>Checkout</button>
      </div>
    </Layout>
  );
};

export default CartPage;
