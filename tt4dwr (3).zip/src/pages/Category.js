const categorylist = [
  {
    id: 1,
    name: "Pizza",
    image:
      "https://imgmedia.lbb.in/media/2019/07/5d242ad8e93a896e5542da0d_1562651352251.jpg"
  },

  {
    id: 2,
    name: "Biriyani",
    image:
      "https://www.licious.in/blog/wp-content/uploads/2022/06/chicken-hyderabadi-biryani-01.jpg"
  },
  {
    id: 3,
    name: "Dessert",
    image:
      "https://images.immediate.co.uk/production/volatile/sites/30/2020/08/dessert-main-image-molten-cake-0fbd4f2.jpg"
  },

  {
    id: 4,
    name: "Noodles",
    image:
      "https://images.immediate.co.uk/production/volatile/sites/30/2020/12/Noodles-with-chilli-oil-eggs-6ec34e9.jpg"
  },
  {
    id: 5,
    name: "Dosa",
    image:
      "https://www.madhuseverydayindian.com/wp-content/uploads/2021/01/dosa-recipe-with-rice-flour-768x1024.jpg"
  },
  {
    id: 6,
    name: "Thali",
    image:
      "https://www.masalabox.com/wp-content/uploads/2022/03/e1dad5315972c8a9db86fb01d69c7ecb.jpg"
  }
];
export default categorylist;
