import React from "react";
import { FaMinus, Faplus } from "react-icons/fa";
import CartPage from "./Cartpage";

const Cartamounttoggle = ({ amount, setIncrease, setDecrease }) => {
  return (
    <div className="cart-btn">
      <div className="amount-toggle">
        <button onClick={() => setDecrease()}>
          <FaMinus />
        </button>
        <div className="amount-style">{amount}</div>
        <button onClick={() => setIncrease()}>
          <Faplus />
        </button>
      </div>
    </div>
  );
};
export default Cartamounttoggle;
